package rbadia.voidspace.model;

import rbadia.voidspace.main.GameScreen;

public class BossShip extends EnemyShip {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BossShip(GameScreen screen){
		super(screen);
	}

}
